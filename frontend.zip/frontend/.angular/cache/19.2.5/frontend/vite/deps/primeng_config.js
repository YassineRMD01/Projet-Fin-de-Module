import {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
} from "./chunk-PC6TYWOQ.js";
import "./chunk-XBTJW5HX.js";
import "./chunk-MSIWIRAO.js";
import "./chunk-SJOX2EEL.js";
import "./chunk-D742Z3C6.js";
import "./chunk-WDMUDEB6.js";
export {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
};
