import {Component, EventEmitter, Output, ViewChild, WritableSignal} from '@angular/core';
import {FormBuilder} from "@angular/forms";
import {NgbModal, NgbPagination} from "@ng-bootstrap/ng-bootstrap";

import {ButtonModule} from "primeng/button";
import {CommonModule} from "@angular/common";
import {DepartementService} from "../../../service/departement.service";

import {TagModule} from "primeng/tag";
import {TableModule} from "primeng/table";
import {RatingModule} from "primeng/rating";
import {DeleteFiliereComponent} from "./delete-filiere/delete-filiere.component";



@Component({
  selector: 'app-list-filiere',
  standalone: true,
  imports: [TableModule, TagModule, RatingModule, ButtonModule, CommonModule, NgbPagination, DeleteFiliereComponent],
  templateUrl: './list-filiere.component.html',
  styleUrl: './list-filiere.component.css'
})
export class ListFiliereComponent {

  departements=this.departementService.departements;

  page = 1;
  pageSize:number=3;

  constructor(private departementService:DepartementService) {}

  @Output() toggleDialog = new EventEmitter<void>();
  @Output() editFiliere = new EventEmitter<any>();

  @ViewChild(DeleteFiliereComponent) deleteFiliere!: DeleteFiliereComponent;

  addFiliere() {
    this.toggleDialog.emit();
  }

  onEditFiliere(filiere: any) {
    this.editFiliere.emit(filiere);
  }

  onDeleteFiliere(departement: any) {
    this.deleteFiliere.departementData = departement;
    this.deleteFiliere.visible = true;
  }


}
