import {ChangeDetectorRef, Component, Input} from '@angular/core';
import {DepartementService} from "../../../../service/departement.service";
import {Dialog} from "primeng/dialog";

@Component({
  selector: 'app-delete-filiere',
  standalone: true,
  imports: [
    Dialog
  ],
  templateUrl: './delete-filiere.component.html',
  styleUrl: './delete-filiere.component.css'
})
export class DeleteFiliereComponent {
   @Input() departementData:any;
   @Input() visible:boolean=false;
  constructor(private departementService:DepartementService,
              private cdr:ChangeDetectorRef,) {
  }

  deleteFiliere(id:number){
    this.departementService.deleteDepartement(id);
    this.cdr.detectChanges();
    this.closeModal();
  }

  closeModal() {
    this.visible=false;
  }
}
