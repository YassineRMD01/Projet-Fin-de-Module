import {ChangeDetectorRef, Component, ViewChild} from '@angular/core';
import {ListFiliereComponent} from "./list-filiere/list-filiere.component";
import {FormFiliereComponent} from "./form-filiere/form-filiere.component";

@Component({
  selector: 'app-filiere',
  standalone: true,
  imports: [
    ListFiliereComponent,

    FormFiliereComponent
  ],
  templateUrl: './filiere.component.html',
  styleUrl: './filiere.component.css'
})
export class FiliereComponent {
  constructor(private cdr: ChangeDetectorRef) {
  }
  @ViewChild(FormFiliereComponent) formFiliereComponent!:FormFiliereComponent;


  showDialog() {
    this.formFiliereComponent.visible = true;
    this.cdr.detectChanges();
  }

  updateFiliere(filiere: any) {
    this.formFiliereComponent.departementData= filiere;
    this.formFiliereComponent.action = 'Modifier';
    this.formFiliereComponent.visible = true; // Make the form visible
    this.cdr.detectChanges();
  }
}
