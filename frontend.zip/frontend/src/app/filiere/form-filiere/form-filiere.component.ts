import {Component, Input, OnInit} from '@angular/core';
import {Dialog} from "primeng/dialog";
import {FormBuilder, FormGroup, ReactiveFormsModule, Validators} from "@angular/forms";
import {DepartementService} from "../../../service/departement.service";

@Component({
  selector: 'app-form-filiere',
  standalone: true,
  imports: [
    Dialog,
    ReactiveFormsModule
  ],
  templateUrl: './form-filiere.component.html',
  styleUrl: './form-filiere.component.css'
})
export class FormFiliereComponent implements OnInit {
  constructor(private fb: FormBuilder, private departementService: DepartementService) {}

  ngOnInit() {
    this.formDepartement = this.fb.group({
      nomDepartement: ['', Validators.required]
    });
  }

  @Input() visible: boolean = false;

  formDepartement!: FormGroup;

  private _departementData: any;
  private _action: string = 'Ajouter';

  @Input()
  set departementData(value: any) {
    this._departementData = value;
    this.updateForm();
  }

  get departementData(): any {
    return this._departementData;
  }

  @Input()
  set action(value: string) {
    this._action = value;
    this.updateForm();
  }

  get action(): string {
    return this._action;
  }

  updateForm() {
    if (this._action === 'Modifier' && this._departementData) {
      this.formDepartement = this.fb.group({
        id: [this._departementData.id, Validators.required],
        nomDepartement: [this._departementData.nomDepartement, Validators.required]
      });
    } else if (this._action === 'Ajouter') {
      this.formDepartement.reset(); // Clear form for adding new data
    }
  }

  actionDepartement() {
    if (this.action === "Ajouter") {
      this.addDepartement();
    } else {
      this.updateDepartement({
        id: this.formDepartement.value.id,
        nomDepartement: this.formDepartement.value.nomDepartement
      });
    }
    this.closeModal();
  }

  addDepartement() {
    this.departementService.addDepartement(this.formDepartement.value);
  }

  updateDepartement(departement: any) {
    this.departementService.updateDepartement(departement);
  }

  closeModal() {
    this.visible = false;
    this.formDepartement.reset();
  }
}
