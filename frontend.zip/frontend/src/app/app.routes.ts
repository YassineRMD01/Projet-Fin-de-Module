import { Routes } from '@angular/router';
import {EtudiantComponent} from "./etudiant/etudiant.component";

import {FiliereComponent} from "./filiere/filiere.component";

export const routes: Routes = [
  {path:"", redirectTo:"etudiants", pathMatch:"full"},
  {path:"etudiants", component: EtudiantComponent},
  {path:"filieres", component: FiliereComponent},
];
