import { Component, Input} from '@angular/core';
import {FormBuilder, ReactiveFormsModule, Validators} from "@angular/forms";
import {Dialog} from "primeng/dialog";
import {EmployeeService} from "../../../../service/employee.service";
import {DepartementService} from "../../../../service/departement.service";

@Component({
  selector: 'app-form',
  standalone: true,
  imports: [ReactiveFormsModule, Dialog],
  templateUrl: './form.component.html',
  styleUrl: './form.component.css'
})
export class FormComponent {
  constructor(
    private fb: FormBuilder,
    private employeeService: EmployeeService,
    private departementService: DepartementService
  ) {}

  @Input() visible: boolean = false;

  formEmployee = this.fb.group({
    id: [''],
    firstName: ['', Validators.required],
    lastName: ['', Validators.required],
    birthDate: ['', Validators.required],
    departementId: ['', Validators.required],
  });

  photo!: File;

  departements = this.departementService.departements;

  private _employeeData: any = null;
  private _action: string = 'Ajouter';

  @Input()
  set employeeData(value: any) {
    this._employeeData = value;
    this.updateForm();
  }

  get employeeData(): any {
    return this._employeeData;
  }

  @Input()
  set action(value: string) {
    this._action = value;
    this.updateForm();
  }

  get action(): string {
    return this._action;
  }

  updateForm() {
    if (this._action === 'Modifier' && this._employeeData) {
      this.formEmployee.setValue({
        id: this._employeeData.id || '',
        firstName: this._employeeData.firstName || '',
        lastName: this._employeeData.lastName || '',
        birthDate: this._employeeData.birthDate || '',
        departementId: this._employeeData.departement?.id || '',
      });
    } else if (this._action === 'Ajouter') {
      this.formEmployee.reset();
    }
  }

  actionEmployee() {
    if (this.action === 'Ajouter') {
      this.addEmployee();
    } else {
      this.updateEmployee({
        id: this.formEmployee.value.id,
        firstName: this.formEmployee.value.firstName,
        lastName: this.formEmployee.value.lastName,
        birthDate: this.formEmployee.value.birthDate,
        departementId: this.formEmployee.value.departementId,
      });
    }
    this.closeModal();
  }

  addEmployee() {
    this.employeeService.addEmployee(this.formEmployee.value, this.photo);
  }

  fileSelected(event: any) {
    const file = event.target.files[0];
    if (file) this.photo = file;
  }

  updateEmployee(employee: any) {
    this.employeeService.updateEmployee(employee.id, employee);
  }

  closeModal() {
    this.visible = false;
    this.formEmployee.reset();
  }
}
