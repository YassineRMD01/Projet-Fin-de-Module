import {Component, EventEmitter, Input, Output} from '@angular/core';
import {Dialog} from "primeng/dialog";
import {EmployeeService} from "../../../../service/employee.service";


@Component({
  selector: 'app-delete-modal',
  standalone: true,
  imports: [
    Dialog
  ],
  templateUrl: './delete-modal.component.html',
  styleUrl: './delete-modal.component.css',
  providers:[EmployeeService]
})
export class DeleteModalComponent {
  @Input() visible: boolean = false;
  @Input() employeeData: any = null;
  @Output() confirmDelete = new EventEmitter<boolean>();

  deleteEmployee() {
    this.confirmDelete.emit(true);
    this.visible = false;
  }
}
