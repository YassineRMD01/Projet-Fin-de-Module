import { Component, ViewChild} from '@angular/core';

import {NgbPagination} from "@ng-bootstrap/ng-bootstrap";

import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import {DeleteModalComponent} from "./delete-modal/delete-modal.component";

import {TableModule} from "primeng/table";
import {TagModule} from "primeng/tag";
import {RatingModule} from "primeng/rating";
import {ButtonModule} from "primeng/button";
import {CommonModule} from "@angular/common";

import {FormComponent} from "./form/form.component";
import {EmployeeService} from "../../../service/employee.service";
import {DepartementService} from "../../../service/departement.service";
import {Employee} from "../../../model/employee";

@Component({
  selector: 'app-list-etudiant',
  standalone: true,
  imports: [
    FormsModule,
    ReactiveFormsModule,
    TableModule, TagModule, RatingModule, ButtonModule, CommonModule, NgbPagination, DeleteModalComponent, FormComponent
  ],
  templateUrl: './list-etudiant.component.html',
  styleUrl: './list-etudiant.component.css',
  providers: [EmployeeService,DepartementService]
})
export class ListEtudiantComponent {
  page = 1;
  pageSize: number = 5;
  search: number = 0;

  employees = this.employeeService.employees;
  departements = this.departementService.departements;

  constructor(private employeeService: EmployeeService,
              private departementService: DepartementService) {
  }

  @ViewChild(DeleteModalComponent) deleteModal!: DeleteModalComponent;
  @ViewChild(FormComponent) formComponent!: FormComponent;

  addEmployee() {
    this.formComponent.visible = true;
  }

  onEditEmployee(employee: Employee) {
    this.formComponent.employeeData = employee;
    this.formComponent.action = 'Modifier';
    this.formComponent.visible = true;
  }

  onDeleteEmployee(employee: Employee) {
    this.deleteModal.employeeData = employee;
    this.deleteModal.visible = true;
  }

  handleDeleteAction(deleteConfirmed: boolean, employeeId: number) {
    if (deleteConfirmed) {
      this.employeeService.deleteEmployee(employeeId);
    }
  }
}
