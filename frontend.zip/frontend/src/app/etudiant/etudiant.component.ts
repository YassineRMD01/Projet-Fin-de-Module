import { Component} from '@angular/core';
import {ListEtudiantComponent} from "./list-etudiant/list-etudiant.component";


@Component({
  selector: 'app-etudiant',
  standalone: true,
  imports: [
    ListEtudiantComponent,
  ],
  templateUrl: './etudiant.component.html',
  styleUrl: './etudiant.component.css'
})
export class EtudiantComponent {

}
