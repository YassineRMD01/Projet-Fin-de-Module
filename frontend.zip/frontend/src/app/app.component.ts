import {Component} from '@angular/core';
import {Router, RouterModule, RouterOutlet} from '@angular/router';
import {NavBarComponent} from "./home/nav-bar/nav-bar.component";
import { PrimeNG } from 'primeng/config';
import Aura from '@primeng/themes/aura';
@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, RouterModule, NavBarComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'Project';

  constructor(private router: Router,private primeng: PrimeNG) {
  primeng.theme.set({
                           preset: Aura,
                           options: {
                             cssLayer: {
                               name: 'primeng',
                               order: 'tailwind-base, primeng, tailwind-utilities'
                             }
                           }
                         })
}


}
