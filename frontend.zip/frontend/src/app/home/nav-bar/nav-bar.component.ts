import {Component, ViewChild} from '@angular/core';
import {ButtonModule} from "primeng/button";
import {AvatarModule} from "primeng/avatar";
import {Drawer, DrawerModule} from "primeng/drawer";
import {Ripple} from "primeng/ripple";
import {StyleClass} from "primeng/styleclass";
import {RouterLink} from "@angular/router";



@Component({
  selector: 'app-nav-bar',
  standalone: true,
  imports: [DrawerModule, ButtonModule, Ripple, AvatarModule, StyleClass, RouterLink],
  templateUrl: './nav-bar.component.html',
  styleUrl: './nav-bar.component.css'
})
export class NavBarComponent {
  @ViewChild('drawerRef') drawerRef!: Drawer;

  closeCallback(e:any): void {
    this.drawerRef.close(e);
  }

  visible: boolean = false;
}
