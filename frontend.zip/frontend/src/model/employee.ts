import {Departement} from './departement';

export interface Employee{
  id:number;
  firstName:string;
  lastName:string;
  birthDate:Date;
  photo:string;
  departement:Departement;
}
