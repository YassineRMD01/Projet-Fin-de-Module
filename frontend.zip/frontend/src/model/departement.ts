import {Employee} from './employee';

export interface Departement {
  id: number;
  name: string; // Changed from firstName to name for consistency
  employees: Employee[];
}
