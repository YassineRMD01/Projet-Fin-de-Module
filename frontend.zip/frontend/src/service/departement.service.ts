import {Injectable, signal} from '@angular/core';
import {Departement} from '../model/departement';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DepartementService {
  private backEndURLDepartement = 'http://localhost:8080/departements';
  private backEndURL = 'http://localhost:8080/';

  departements = signal<Departement[]>([]);

  constructor(private http: HttpClient) {
    this.getAllDepartements(); // Initialize by fetching departments
  }

  // Fetch all departments
  getAllDepartements(): void {
    this.http.get<Departement[]>(this.backEndURLDepartement).subscribe((data) => {
      this.departements.set(data);
    });
  }

  // Add a new department
  addDepartement(departement: any): void {
    this.http.post<Departement>(this.backEndURLDepartement,departement).pipe(
      // You can add additional logic here (like toast notifications)
    ).subscribe((newDepartement) => {
      this.departements.update((state: Departement[]) => [...state, newDepartement]);
    });
  }

  // Update an existing department
  updateDepartement(departement: Departement): void {
    this.http.put<Departement>(`${this.backEndURLDepartement}/${departement.id}`, departement).pipe(
      // You can add additional logic here (like toast notifications)
    ).subscribe((updatedDepartement) => {
      this.departements.update((state: Departement[]) =>
        state.map((dep: Departement) => (dep.id === updatedDepartement.id ? updatedDepartement : dep))
      );
    });
  }

  // Delete a department
  deleteDepartement(id: number): void {
    this.http.delete<boolean>(`${this.backEndURLDepartement}/${id}`).pipe(
      // You can add additional logic here (like toast notifications)
    ).subscribe((success) => {
      if (success) {
        this.departements.update((state: Departement[]) => state.filter((dep) => dep.id !== id));
      }
    });
  }
}
