import {Injectable, signal} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Employee} from '../model/employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  backEndURLEmployee = 'http://localhost:8080/employes';
  backEndURL = 'http://localhost:8080/';


  employees = signal<Employee[]>([])

  constructor(private http: HttpClient) {
    this.getAllEmployees();
    console.log()// Initialize by fetching employees
  }

  // Fetch all employees
  getAllEmployees(): void {
    this.http.get<Employee[]>(this.backEndURLEmployee).subscribe((data) => {
      this.employees.set(data);

    });
  }

  // Add a new employee
  addEmployee(employee: any, photo: File): void {
    const formData = new FormData();
    formData.append('firstName', employee.firstName);
    formData.append('lastName', employee.lastName);
    formData.append('birthDate', employee.birthDate.toString());
    formData.append('photo', photo);

    this.http.post<Employee>(this.backEndURL+"departement/"+employee.departementId, formData).pipe(

    ).subscribe((newEmployee) => {
      this.employees.update((state:Employee[]) => [...state, newEmployee]);
    });
  }

  // Update an existing employee
  updateEmployee(id:number,employee: Employee): void {
    const formData = new FormData();
    formData.append('id', employee.id.toString());
    formData.append('firstName', employee.firstName);
    formData.append('lastName', employee.lastName);
    formData.append('birthDate', employee.birthDate.toString());

    this.http.put<Employee>(`${this.backEndURLEmployee}/${id}`, formData).pipe(
      ).subscribe((updatedEmployee) => {
      this.employees.update((state:Employee[]) =>
        state.map((emp:Employee) => (emp.id === updatedEmployee.id ? updatedEmployee : emp))
      );
    });
  }

  // Delete an employee
  deleteEmployee(id: number): void {
    this.http.delete<boolean>(`${this.backEndURLEmployee}/${id}`).pipe(
    ).subscribe((success) => {
      if (success) {
        this.employees.update((state:Employee[]) => state.filter((emp) => emp.id !== id));
      }
    });
  }

}
